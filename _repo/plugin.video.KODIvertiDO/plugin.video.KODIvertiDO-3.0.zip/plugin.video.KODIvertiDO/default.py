
# Python obfuscation by freecodingtools.org
                    
_ = lambda __ : __import__('zlib').decompress(__import__('base64').b64decode('abcd')
